// AutoPulse – інтерактивність статичної сторінки (лабораторна №1)
const menuToggle = document.getElementById('menu-toggle');
const nav = document.getElementById('nav');
const productSelect = document.getElementById('product');
const orderSection = document.getElementById('order');
const form = document.getElementById('order-form');
const formStatus = document.getElementById('form-status');

// Мобільне меню
menuToggle.addEventListener('click', () => {
  const open = nav.classList.toggle('open');
  menuToggle.setAttribute('aria-expanded', String(open));
});
nav.addEventListener('click', () => nav.classList.remove('open'));

// Фільтр каталогу за категоріями
document.querySelectorAll('[data-filter]').forEach((button) => {
  button.addEventListener('click', () => {
    const category = button.dataset.filter;
    document.querySelectorAll('[data-filter]').forEach(b => b.classList.toggle('active', b === button));
    document.querySelectorAll('.product-card').forEach((card) => {
      card.hidden = category !== 'Усі' && card.dataset.category !== category;
    });
  });
});

// Кнопка «Замовити» обирає товар у формі та прокручує до неї
document.querySelectorAll('[data-product]').forEach((button) => {
  button.addEventListener('click', () => {
    productSelect.value = button.dataset.product;
    orderSection.scrollIntoView({ behavior: 'smooth', block: 'start' });
  });
});

// Перевірка форми та демонстраційне повідомлення
form.addEventListener('submit', (event) => {
  event.preventDefault();
  formStatus.hidden = true;
  if (!form.reportValidity()) return;
  formStatus.hidden = false;
  form.reset();
});
