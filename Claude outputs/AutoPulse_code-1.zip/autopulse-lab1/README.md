# AutoPulse — інтернет-магазин автотоварів (лабораторна №1)

Навчальний статичний сайт на HTML5, CSS3 і JavaScript. Публікується через GitHub Pages.

> Це навчальний проєкт, а не справжній магазин. Ціни умовні, форма заявки працює в демонстраційному режимі і нікуди не надсилає дані.

## Технології
- **HTML5** — семантична структура (`header`, `nav`, `main`, `section`, `article`, `footer`), форма з нативною валідацією, `details/summary` для FAQ.
- **CSS3** — змінні, Flexbox, CSS Grid, медіазапити для смартфонів.
- **JavaScript** — мобільне меню, фільтр каталогу, вибір товару кнопкою «Замовити», перевірка форми.

## Структура
```
autopulse-lab1/
├── index.html      – розмітка сторінки
├── styles.css      – стилі та адаптивність
├── script.js       – інтерактивність
├── assets/
│   └── favicon.svg
└── README.md
```

## Локальний запуск
1. Відкрийте папку у VS Code (**File → Open Folder**).
2. Встановіть розширення **Live Server**.
3. Правою кнопкою на `index.html` → **Open with Live Server** (адреса `http://127.0.0.1:5500`).

## Публікація на GitHub Pages
1. На GitHub створіть публічний репозиторій `autopulse-shop`.
2. У терміналі VS Code:
```powershell
git init
git add .
git commit -m "Initial commit: AutoPulse auto parts website"
git branch -M main
git remote add origin https://github.com/<ваш-логін>/autopulse-shop.git
git push -u origin main
```
3. **Settings → Pages → Deploy from a branch → main → /(root) → Save**.
4. Через 1–2 хв сайт буде доступний за адресою `https://<ваш-логін>.github.io/autopulse-shop/`.
